// FAULTY counter with 6 different bugs (for demo)
module updown_counter (
    input        clk, reset, enable, up_down,
    output reg [3:0] count
);
    always @(posedge clk) begin
        // BUG 4: reset is IGNORED when enable=1 and count > 5
        if (reset && !(enable && count > 4'd5))
            count <= 4'd0;
        else if (enable) begin
            if (up_down) begin
                if (count == 4'd7) count <= 4'd9;       // BUG 1: skips 8
                else               count <= count + 4'd1;
            end else begin
                if      (count == 4'd6) count <= 4'd2;  // BUG 2: skips 5,4,3
                else if (count == 4'd0) count <= 4'd0;  // BUG 3: no wrap, stuck at 0
                else                    count <= count - 4'd1;
            end
        end
        else if (!up_down)
            count <= count - 4'd1;                      // BUG 5: drifts while enable=0
    end

    // BUG 6: count changes on the FALLING edge (not allowed in a sync design)
    always @(negedge clk)
        if (enable && up_down && count == 4'd11)
            count <= 4'd14;
endmodule