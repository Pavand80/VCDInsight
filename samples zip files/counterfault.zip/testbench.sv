`timescale 1ns/1ps
module tb;
    reg clk, reset, enable, up_down;
    wire [3:0] count;

    updown_counter dut (.clk(clk), .reset(reset), .enable(enable),
                        .up_down(up_down), .count(count));

    initial clk = 0;
    always #5 clk = ~clk;

    // ---- Golden reference model (correct counter) ----
    reg [3:0] ref_cnt;
    integer errors;
    initial errors = 0;

    always @(posedge clk) begin
        if (reset)       ref_cnt <= 4'd0;
        else if (enable) ref_cnt <= up_down ? ref_cnt + 4'd1 : ref_cnt - 4'd1;
    end

    // ---- Checker: compare 2 ns after every rising edge ----
    always @(posedge clk) begin
        #2;
        if (count !== ref_cnt) begin
            errors = errors + 1;
            $display("MISMATCH t=%0t expected=%0d got=%0d", $time, ref_cnt, count);
        end
    end

    initial begin
        $dumpfile("dump.vcd");
        $dumpvars(0, tb);

        reset = 1; enable = 0; up_down = 1;
        repeat (3) @(negedge clk);
        reset = 0;
        repeat (2) @(negedge clk);

        enable = 1; up_down = 1;          // count up 20 cycles
        repeat (20) @(negedge clk);

        up_down = 0;                      // count down 8 cycles
        repeat (8) @(negedge clk);

        enable = 0;                       // pause 5 cycles (must hold)
        repeat (5) @(negedge clk);

        enable = 1;                       // resume down 5 cycles
        repeat (5) @(negedge clk);

        reset = 1;                        // reset in the middle
        repeat (2) @(negedge clk);
        reset = 0;

        repeat (3) @(negedge clk);
        enable = 0;
        repeat (2) @(negedge clk);

        $display("TOTAL MISMATCHES = %0d", errors);
        if (errors == 0) $display("RESULT: PASS");
        else             $display("RESULT: FAIL");
        $finish;
    end
endmodule