// Code your design here
// FAULTY 8-bit ALU with 5 bugs (for demo)
module alu8 (
    input            clk, rst_n,
    input      [7:0] a, b,
    input      [2:0] op,
    output reg [7:0] result,
    output reg       zero, carry, overflow
);
    reg [8:0] nxt;
    reg       c_n, v_n;

    always @(*) begin
        nxt = 9'd0; c_n = 1'b0; v_n = 1'b0;
        case (op)
            3'b000: begin                                   // ADD
                nxt = {1'b0, a} + {1'b0, b};
                c_n = nxt[8];
                v_n = 1'b0;                                 // BUG 3: overflow never detected on ADD
            end
            3'b001: begin                                   // SUB
                nxt = {1'b0, a} - {1'b0, b};
                c_n = ~nxt[8];                              // BUG 4: borrow flag is inverted
                v_n = (a[7] != b[7]) && (nxt[7] != a[7]);
            end
            3'b010: nxt = {1'b0, a & b};
            3'b011: nxt = {1'b0, a | b};
            3'b100: nxt = {1'b0, a | b};                    // BUG 1: XOR behaves like OR
            3'b101: begin nxt = {a, 1'b0}; c_n = a[7]; end
            3'b110: begin nxt = {1'b0, a[7], a[7:1]}; c_n = a[0]; end // BUG 5: arithmetic shift (sign kept)
            3'b111: nxt = {1'b0, a};
            default: nxt = 9'd0;
        endcase
    end

    always @(posedge clk) begin
        if (!rst_n) begin
            result <= 8'h00; zero <= 1'b1; carry <= 1'b0; overflow <= 1'b0;
        end else begin
            result   <= nxt[7:0];
            zero     <= (nxt[3:0] == 4'h0);                 // BUG 2: zero checks only the low 4 bits
            carry    <= c_n;
            overflow <= v_n;
        end
    end
endmodule