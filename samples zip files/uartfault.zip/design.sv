// Code your design here
// FAULTY UART transmitter with 4 bugs (for demo)
module uart_tx (
    input        clk, rst_n, start,
    input  [7:0] data,
    output       tx,
    output reg   busy, done
);
    localparam IDLE = 2'd0, START = 2'd1, DATA = 2'd2, STOP = 2'd3;
    reg [1:0] st;
    reg [4:0] baud_cnt;
    reg [2:0] bit_idx;
    reg [7:0] shreg;
    reg       tx_r;

    // BUG 4: tx dips low for one clock whenever done pulses (glitch on idle line)
    assign tx = tx_r & ~done;

    always @(posedge clk) begin
        if (!rst_n) begin
            st <= IDLE; tx_r <= 1'b1; busy <= 1'b0; done <= 1'b0;
            baud_cnt <= 5'd0; bit_idx <= 3'd0; shreg <= 8'd0;
        end else begin
            done <= 1'b0;
            if (start) begin                       // BUG 3: start accepted in ANY state
                shreg <= data; busy <= 1'b1; tx_r <= 1'b0;
                baud_cnt <= 5'd0; st <= START;
            end else begin
                case (st)
                    IDLE: tx_r <= 1'b1;
                    START: begin
                        if (baud_cnt == 5'd15) begin
                            baud_cnt <= 5'd0; bit_idx <= 3'd0;
                            tx_r  <= shreg[7];     // BUG 1: MSB first (wrong order)
                            shreg <= {shreg[6:0], 1'b0};
                            st    <= DATA;
                        end else baud_cnt <= baud_cnt + 5'd1;
                    end
                    DATA: begin
                        if (baud_cnt == 5'd11) begin   // BUG 2: data bits last 12 clocks, not 16
                            baud_cnt <= 5'd0;
                            if (bit_idx == 3'd7) begin
                                tx_r <= 1'b1; st <= STOP;
                            end else begin
                                bit_idx <= bit_idx + 3'd1;
                                tx_r    <= shreg[7];
                                shreg   <= {shreg[6:0], 1'b0};
                            end
                        end else baud_cnt <= baud_cnt + 5'd1;
                    end
                    STOP: begin
                        if (baud_cnt == 5'd15) begin
                            baud_cnt <= 5'd0; busy <= 1'b0; done <= 1'b1; st <= IDLE;
                        end else baud_cnt <= baud_cnt + 5'd1;
                    end
                endcase
            end
        end
    end
endmodule