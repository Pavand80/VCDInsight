// Code your testbench here
// or browse Examples
`timescale 1ns/1ps
module tb;
    reg        clk, rst_n;
    reg  [7:0] a, b;
    reg  [2:0] op;
    wire [7:0] result;
    wire       zero, carry, overflow;
    integer    errors, tests;

    alu8 dut (.clk(clk), .rst_n(rst_n), .a(a), .b(b), .op(op),
              .result(result), .zero(zero), .carry(carry), .overflow(overflow));

    // 10 ns clock (posedges at 5, 15, 25 ...)
    initial clk = 0;
    always #5 clk = ~clk;

    // Apply one operation, wait for the clock edge, then check result and flags
    task do_op(input [2:0] o, input [7:0] x, input [7:0] y,
               input [7:0] er, input ez, input ec, input ev);
    begin
        op = o; a = x; b = y;              // inputs change at the falling edge
        @(posedge clk); #1;                // outputs are registered: check 1 ns after the edge
        tests = tests + 1;
        if (result !== er || zero !== ez || carry !== ec || overflow !== ev) begin
            errors = errors + 1;
            $display("MISMATCH t=%0t op=%b a=%h b=%h | exp res=%h z=%b c=%b v=%b | got res=%h z=%b c=%b v=%b",
                     $time, o, x, y, er, ez, ec, ev, result, zero, carry, overflow);
        end else
            $display("OK       t=%0t op=%b a=%h b=%h res=%h z=%b c=%b v=%b",
                     $time, o, x, y, result, zero, carry, overflow);
        @(negedge clk);
    end
    endtask

    initial begin
        $dumpfile("dump.vcd");
        $dumpvars(0, tb);

        errors = 0; tests = 0;
        rst_n = 0; a = 0; b = 0; op = 0;
        repeat (3) @(negedge clk);          // reset until t=30
        rst_n = 1;

        //          op     a      b      res    z  c  v
        // ---- ADD ----
        do_op(3'b000, 8'h10, 8'h20, 8'h30, 0, 0, 0);   // normal add
        do_op(3'b000, 8'hFF, 8'h01, 8'h00, 1, 1, 0);   // carry out, zero
        do_op(3'b000, 8'h7F, 8'h01, 8'h80, 0, 0, 1);   // signed overflow
        do_op(3'b000, 8'h80, 8'h80, 8'h00, 1, 1, 1);   // carry + overflow + zero
        // ---- SUB ----
        do_op(3'b001, 8'h30, 8'h10, 8'h20, 0, 0, 0);   // normal sub
        do_op(3'b001, 8'h10, 8'h10, 8'h00, 1, 0, 0);   // zero result
        do_op(3'b001, 8'h10, 8'h20, 8'hF0, 0, 1, 0);   // borrow (a < b)
        do_op(3'b001, 8'h80, 8'h01, 8'h7F, 0, 0, 1);   // signed overflow
        // ---- Logic ----
        do_op(3'b010, 8'hF0, 8'h3C, 8'h30, 0, 0, 0);   // AND
        do_op(3'b010, 8'hF0, 8'h0F, 8'h00, 1, 0, 0);   // AND -> zero
        do_op(3'b011, 8'hA0, 8'h05, 8'hA5, 0, 0, 0);   // OR
        do_op(3'b100, 8'hFF, 8'hFF, 8'h00, 1, 0, 0);   // XOR -> zero
        do_op(3'b100, 8'hAA, 8'h55, 8'hFF, 0, 0, 0);   // XOR
        // ---- Shifts ----
        do_op(3'b101, 8'h81, 8'h00, 8'h02, 0, 1, 0);   // shift left, carry = old bit 7
        do_op(3'b101, 8'h40, 8'h00, 8'h80, 0, 0, 0);   // shift left
        do_op(3'b110, 8'h03, 8'h00, 8'h01, 0, 1, 0);   // shift right, carry = old bit 0
        do_op(3'b110, 8'h80, 8'h00, 8'h40, 0, 0, 0);   // shift right (logical, not sign-extended)
        // ---- Pass A ----
        do_op(3'b111, 8'h5A, 8'hFF, 8'h5A, 0, 0, 0);   // pass A, b ignored
        do_op(3'b111, 8'h00, 8'hFF, 8'h00, 1, 0, 0);   // pass 0 -> zero flag
        // ---- Reset in the middle: ADD 7F+01 would give 80 with overflow, reset must win ----
        rst_n = 0;
        do_op(3'b000, 8'h7F, 8'h01, 8'h00, 1, 0, 0);
        rst_n = 1;                                      // released: ALU computes again

        repeat (2) @(negedge clk);

        $display("TESTS=%0d ERRORS=%0d", tests, errors);
        if (errors == 0 && tests == 20) $display("RESULT: PASS");
        else                            $display("RESULT: FAIL");
        $finish;
    end
endmodule