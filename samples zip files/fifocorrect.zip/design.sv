// Code your design here
// Synchronous FIFO, depth 8, width 8, valid/ready handshake
module sync_fifo (
    input        clk,
    input        rst_n,        // synchronous, active low
    input        in_valid,
    input  [7:0] in_data,
    output       in_ready,
    output       out_valid,
    output [7:0] out_data,
    input        out_ready,
    output       full,
    output       empty
);
    reg [7:0] mem [0:7];
    reg [2:0] wr_ptr, rd_ptr;
    reg [3:0] count;                       // 0..8 entries stored

    assign full      = (count == 4'd8);
    assign empty     = (count == 4'd0);
    assign in_ready  = ~full;              // can accept when not full
    assign out_valid = ~empty;             // data available when not empty
    assign out_data  = empty ? 8'h00 : mem[rd_ptr];   // oldest byte

    wire push = in_valid  & in_ready;      // write handshake
    wire pop  = out_valid & out_ready;     // read handshake

    always @(posedge clk) begin
        if (!rst_n) begin
            wr_ptr <= 3'd0;
            rd_ptr <= 3'd0;
            count  <= 4'd0;
        end else begin
            if (push) begin
                mem[wr_ptr] <= in_data;
                wr_ptr      <= wr_ptr + 3'd1;
            end
            if (pop)
                rd_ptr <= rd_ptr + 3'd1;

            case ({push, pop})
                2'b10:   count <= count + 4'd1;   // push only
                2'b01:   count <= count - 4'd1;   // pop only
                default: count <= count;          // none or both
            endcase
        end
    end
endmodule