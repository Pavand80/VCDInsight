// Code your design here
// UART transmitter 8N1, baud divider = 16 clocks per bit
module uart_tx (
    input        clk,
    input        rst_n,     // synchronous, active low
    input        start,     // 1-cycle pulse, only accepted when idle
    input  [7:0] data,
    output reg   tx,        // serial line, idles high
    output reg   busy,      // high during the whole frame
    output reg   done       // 1-cycle pulse when the frame ends
);
    localparam DIV = 16;
    localparam IDLE = 2'd0, START = 2'd1, DATA = 2'd2, STOP = 2'd3;

    reg [1:0] st;
    reg [4:0] baud_cnt;     // counts 0..15 inside each bit
    reg [2:0] bit_idx;      // which data bit is being sent
    reg [7:0] shreg;        // data latched at start

    always @(posedge clk) begin
        if (!rst_n) begin
            st <= IDLE; tx <= 1'b1; busy <= 1'b0; done <= 1'b0;
            baud_cnt <= 5'd0; bit_idx <= 3'd0; shreg <= 8'd0;
        end else begin
            done <= 1'b0;                          // default: done is a pulse
            case (st)
                IDLE: begin
                    tx <= 1'b1;
                    if (start) begin               // accepted only when idle
                        shreg    <= data;          // latch data
                        busy     <= 1'b1;
                        tx       <= 1'b0;          // start bit begins now
                        baud_cnt <= 5'd0;
                        st       <= START;
                    end
                end
                START: begin
                    if (baud_cnt == DIV-1) begin
                        baud_cnt <= 5'd0;
                        bit_idx  <= 3'd0;
                        tx       <= shreg[0];      // D0 first (LSB first)
                        shreg    <= {1'b0, shreg[7:1]};
                        st       <= DATA;
                    end else
                        baud_cnt <= baud_cnt + 5'd1;
                end
                DATA: begin
                    if (baud_cnt == DIV-1) begin
                        baud_cnt <= 5'd0;
                        if (bit_idx == 3'd7) begin // last data bit finished
                            tx <= 1'b1;            // stop bit
                            st <= STOP;
                        end else begin
                            bit_idx <= bit_idx + 3'd1;
                            tx      <= shreg[0];   // next bit
                            shreg   <= {1'b0, shreg[7:1]};
                        end
                    end else
                        baud_cnt <= baud_cnt + 5'd1;
                end
                STOP: begin
                    if (baud_cnt == DIV-1) begin
                        baud_cnt <= 5'd0;
                        busy <= 1'b0;
                        done <= 1'b1;              // 1-cycle pulse
                        st   <= IDLE;
                    end else
                        baud_cnt <= baud_cnt + 5'd1;
                end
            endcase
        end
    end
endmodule