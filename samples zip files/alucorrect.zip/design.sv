// Code your design here
// 8-bit registered ALU, synchronous active-low reset
module alu8 (
    input            clk,
    input            rst_n,      // synchronous, active low
    input      [7:0] a,
    input      [7:0] b,
    input      [2:0] op,         // see operation list
    output reg [7:0] result,
    output reg       zero,
    output reg       carry,
    output reg       overflow
);
    reg [8:0] nxt;               // 9 bits: bit 8 is the carry/borrow
    reg       c_n, v_n;

    // Combinational part: compute the next result and flags
    always @(*) begin
        nxt = 9'd0; c_n = 1'b0; v_n = 1'b0;
        case (op)
            3'b000: begin                                   // ADD
                nxt = {1'b0, a} + {1'b0, b};
                c_n = nxt[8];
                v_n = (a[7] == b[7]) && (nxt[7] != a[7]);
            end
            3'b001: begin                                   // SUB
                nxt = {1'b0, a} - {1'b0, b};
                c_n = nxt[8];                               // borrow
                v_n = (a[7] != b[7]) && (nxt[7] != a[7]);
            end
            3'b010: nxt = {1'b0, a & b};                    // AND
            3'b011: nxt = {1'b0, a | b};                    // OR
            3'b100: nxt = {1'b0, a ^ b};                    // XOR
            3'b101: begin nxt = {a, 1'b0};  c_n = a[7]; end // shift left
            3'b110: begin nxt = {2'b00, a[7:1]}; c_n = a[0]; end // shift right
            3'b111: nxt = {1'b0, a};                        // pass A
            default: nxt = 9'd0;
        endcase
    end

    // Sequential part: register result and flags on the clock edge
    always @(posedge clk) begin
        if (!rst_n) begin
            result   <= 8'h00;
            zero     <= 1'b1;
            carry    <= 1'b0;
            overflow <= 1'b0;
        end else begin
            result   <= nxt[7:0];
            zero     <= (nxt[7:0] == 8'h00);
            carry    <= c_n;
            overflow <= v_n;
        end
    end
endmodule