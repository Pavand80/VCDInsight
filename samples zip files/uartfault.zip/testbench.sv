// Code your testbench here
// or browse Examples
`timescale 1ns/1ps
module tb;
    reg        clk, rst_n, start;
    reg  [7:0] data;
    wire       tx, busy, done;

    uart_tx dut (.clk(clk), .rst_n(rst_n), .start(start), .data(data),
                 .tx(tx), .busy(busy), .done(done));

    // 20 ns clock -> 1 bit = 16 clocks = 320 ns
    initial clk = 0;
    always #10 clk = ~clk;
    parameter BIT = 320;

    // ---------- Receiver-style checker: rebuilds each byte from tx ----------
    reg [7:0] exp [0:7];
    reg [7:0] rx_byte;
    integer   n_rx, errors, k;
    initial begin
        n_rx = 0; errors = 0;
        exp[0] = 8'h55; exp[1] = 8'hA3; exp[2] = 8'h81; exp[3] = 8'h3C;
    end

    always @(negedge tx) begin
        if (rst_n === 1'b1) begin
            #(BIT/2);                                  // middle of start bit
            if (tx !== 1'b0) begin
                errors = errors + 1;
                $display("GLITCH t=%0t: tx went low but it is not a real start bit", $time);
            end else begin
                for (k = 0; k < 8; k = k + 1) begin    // sample D0..D7
                    #(BIT);
                    rx_byte[k] = tx;
                end
                #(BIT);                                // middle of stop bit
                if (tx !== 1'b1) begin
                    errors = errors + 1;
                    $display("FRAMING ERROR t=%0t: stop bit is not 1", $time);
                end
                if (rx_byte !== exp[n_rx]) begin
                    errors = errors + 1;
                    $display("MISMATCH t=%0t byte %0d expected=%h got=%h",
                             $time, n_rx, exp[n_rx], rx_byte);
                end else
                    $display("OK       t=%0t byte %0d = %h", $time, n_rx, rx_byte);
                n_rx = n_rx + 1;
            end
        end
    end

    // ---------- Send one byte and wait for done ----------
    task send_byte(input [7:0] b);
    begin
        @(negedge clk);
        data = b; start = 1'b1;
        @(negedge clk);
        start = 1'b0; data = 8'h00;     // data is removed: design must have latched it
        @(posedge done);
        @(negedge clk);
    end
    endtask

    initial begin
        $dumpfile("dump.vcd");
        $dumpvars(0, tb);

        rst_n = 0; start = 0; data = 8'h00;
        repeat (3) @(negedge clk);
        rst_n = 1;
        repeat (5) @(negedge clk);

        send_byte(8'h55);               // byte 1
        repeat (100) @(negedge clk);    // gap

        send_byte(8'hA3);               // byte 2
        repeat (100) @(negedge clk);    // gap

        // byte 3, with an extra start pulse in the middle (must be ignored)
        @(negedge clk); data = 8'h81; start = 1'b1;
        @(negedge clk); start = 1'b0; data = 8'hFF;
        repeat (40) @(negedge clk);
        start = 1'b1;                   // ignored: busy = 1
        @(negedge clk); start = 1'b0;
        @(posedge done);
        @(negedge clk);
        repeat (100) @(negedge clk);    // gap

        send_byte(8'h3C);               // byte 4
        repeat (50) @(negedge clk);

        $display("TOTAL BYTES=%0d ERRORS=%0d", n_rx, errors);
        if (errors == 0 && n_rx == 4) $display("RESULT: PASS");
        else                          $display("RESULT: FAIL");
        $finish;
    end
endmodule