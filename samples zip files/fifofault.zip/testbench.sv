// Code your testbench here
// or browse Examples
`timescale 1ns/1ps
module tb;
    reg        clk, rst_n, in_valid, out_ready;
    reg  [7:0] in_data;
    wire       in_ready, out_valid, full, empty;
    wire [7:0] out_data;
    integer    i;

    sync_fifo dut (
        .clk(clk), .rst_n(rst_n),
        .in_valid(in_valid), .in_data(in_data), .in_ready(in_ready),
        .out_valid(out_valid), .out_data(out_data), .out_ready(out_ready),
        .full(full), .empty(empty)
    );

    // 10 ns clock
    initial clk = 0;
    always #5 clk = ~clk;

    // ---------- Scoreboard: checks order and value of every byte ----------
    reg [7:0] exp_mem [0:255];
    integer wp, rp, errors;
    initial begin wp = 0; rp = 0; errors = 0; end

    always @(posedge clk) begin
        if (rst_n) begin
            if (in_valid && in_ready) begin          // accepted write
                exp_mem[wp] = in_data;
                wp = wp + 1;
            end
            if (out_valid && out_ready) begin        // accepted read
                if (out_data !== exp_mem[rp]) begin
                    errors = errors + 1;
                    $display("MISMATCH t=%0t expected=%h got=%h",
                             $time, exp_mem[rp], out_data);
                end
                rp = rp + 1;
            end
        end
    end

    // ---------- Stimulus (changes only on falling edge) ----------
    initial begin
        $dumpfile("dump.vcd");
        $dumpvars(0, tb);

        // 1. Reset 3 cycles
        rst_n = 0; in_valid = 0; in_data = 0; out_ready = 0;
        repeat (3) @(negedge clk);
        rst_n = 1;
        @(negedge clk);

        // 2. Fill all 8 entries (out_ready = 0) -> FIFO becomes full
        for (i = 0; i < 8; i = i + 1) begin
            in_valid = 1; in_data = 8'hA0 + i;
            @(negedge clk);
        end

        // 3. Try 2 extra writes while full (must be ignored)
        in_data = 8'hEE; @(negedge clk);
        in_data = 8'hEF; @(negedge clk);
        in_valid = 0;

        // 4. Hold out_ready low for 3 cycles (data must stay, nothing pops)
        repeat (3) @(negedge clk);

        // 5. Drain: 8 pops, then 2 cycles of out_ready on an empty FIFO
        out_ready = 1;
        repeat (10) @(negedge clk);
        out_ready = 0;
        repeat (2) @(negedge clk);

        // 6. Preload 3 entries
        for (i = 0; i < 3; i = i + 1) begin
            in_valid = 1; in_data = 8'hB0 + i;
            @(negedge clk);
        end

        // 7. Simultaneous push and pop for 7 cycles
        out_ready = 1;
        for (i = 3; i < 10; i = i + 1) begin
            in_data = 8'hB0 + i;
            @(negedge clk);
        end
        in_valid = 0;

        // 8. Drain the remaining 3 entries
        repeat (6) @(negedge clk);
        out_ready = 0;
        repeat (2) @(negedge clk);

        $display("TOTAL WRITES=%0d READS=%0d ERRORS=%0d", wp, rp, errors);
        if (errors == 0 && wp == rp) $display("RESULT: PASS");
        else                         $display("RESULT: FAIL");
        $finish;
    end
endmodule