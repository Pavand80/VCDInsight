// Code your design here
// FAULTY traffic light with 4 bugs (for demo)
module traffic_light (
    input        clk, resetn, car_waiting,
    output       red, yellow, green,
    output reg [1:0] state
);
    localparam RED = 2'd0, GREEN = 2'd1, YELLOW = 2'd2;
    reg [3:0] timer;

    assign red    = (state == RED);
    assign green  = (state == GREEN);
    // BUG 4: yellow also turns on during the last GREEN cycle (lights overlap)
    assign yellow = (state == YELLOW) | (state == GREEN && timer == 4'd2);

    always @(posedge clk) begin            // BUG 3: reset is synchronous, not async
        if (!resetn) begin
            state <= RED;
            timer <= 4'd0;
        end else begin
            case (state)
                RED: begin
                    if (timer < 3)
                        timer <= timer + 4'd1;
                    else begin             // BUG 1: car_waiting is ignored
                        state <= GREEN;
                        timer <= 4'd0;
                    end
                end
                GREEN: begin
                    if (timer == 4'd2) begin   // BUG 2: GREEN lasts 3 cycles, not 5
                        state <= YELLOW;
                        timer <= 4'd0;
                    end else
                        timer <= timer + 4'd1;
                end
                YELLOW: begin
                    if (timer == 4'd1) begin
                        state <= RED;
                        timer <= 4'd0;
                    end else
                        timer <= timer + 4'd1;
                end
                default: begin state <= RED; timer <= 4'd0; end
            endcase
        end
    end
endmodule