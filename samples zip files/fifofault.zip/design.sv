// Code your design here
// FAULTY FIFO with 4 bugs (for demo)
module sync_fifo (
    input        clk, rst_n, in_valid,
    input  [7:0] in_data,
    output       in_ready,
    output       out_valid,
    output [7:0] out_data,
    input        out_ready,
    output       full, empty
);
    reg [7:0] mem [0:7];
    reg [2:0] wr_ptr, rd_ptr;
    reg [3:0] count;

    assign full      = (count == 4'd8);
    assign empty     = (count == 4'd0);
    assign in_ready  = 1'b1;                          // BUG 1: stays high when full
    assign out_valid = ~empty;
    assign out_data  = empty ? 8'h00
                             : {1'b0, mem[rd_ptr][6:0]};  // BUG 2: bit 7 stuck at 0

    wire push = in_valid;                             // BUG 1: no ready check
    wire pop  = out_valid & out_ready;
    wire both = push & pop;

    always @(posedge clk) begin
        if (!rst_n) begin
            wr_ptr <= 0; rd_ptr <= 0; count <= 0;
        end else begin
            // BUG 4: when push and pop happen together, the push is lost
            if (push && !both) begin
                mem[wr_ptr] <= in_data;               // BUG 1: overwrites old data when full
                wr_ptr      <= wr_ptr + 3'd1;
            end
            if (out_ready)                            // BUG 3: read pointer moves even when empty
                rd_ptr <= rd_ptr + 3'd1;

            if (both)              count <= count - 4'd1;
            else if (push)         begin if (count != 4'd8) count <= count + 4'd1; end
            else if (pop)          count <= count - 4'd1;
        end
    end
endmodule