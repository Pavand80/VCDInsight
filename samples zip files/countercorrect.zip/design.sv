// Code your design here
// 4-bit up/down counter, synchronous active-high reset
module updown_counter (
    input        clk,
    input        reset,    // synchronous, active high
    input        enable,   // 1 = count, 0 = hold
    input        up_down,  // 1 = up, 0 = down
    output reg [3:0] count
);
    always @(posedge clk) begin
        if (reset)
            count <= 4'd0;              // reset wins over everything
        else if (enable) begin
            if (up_down)
                count <= count + 4'd1;  // wraps 15 -> 0 automatically
            else
                count <= count - 4'd1;  // wraps 0 -> 15 automatically
        end
        // enable = 0: count keeps its value
    end
endmodule