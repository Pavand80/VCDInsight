// Code your testbench here
// or browse Examples
`timescale 1ns/1ps
module tb;
    reg clk, reset, enable, up_down;
    wire [3:0] count;

    updown_counter dut (
        .clk(clk), .reset(reset), .enable(enable),
        .up_down(up_down), .count(count)
    );

    // 10 ns clock
    initial clk = 0;
    always #5 clk = ~clk;

    initial begin
        $dumpfile("dump.vcd");
        $dumpvars(0, tb);

        // 1. Reset for 3 cycles
        reset = 1; enable = 0; up_down = 1;
        repeat (3) @(negedge clk);
        reset = 0;

        // 2. Idle with enable = 0 (count must stay 0)
        repeat (2) @(negedge clk);

        // 3. Count UP for 20 cycles (0 -> 15 -> wraps -> 4)
        enable = 1; up_down = 1;
        repeat (20) @(negedge clk);

        // 4. Switch to DOWN for 8 cycles (4 -> 0 -> wraps -> 12)
        up_down = 0;
        repeat (8) @(negedge clk);

        // 5. Pause: enable = 0 for 5 cycles (count must hold at 12)
        enable = 0;
        repeat (5) @(negedge clk);

        // 6. Resume DOWN for 5 cycles (12 -> 7)
        enable = 1;
        repeat (5) @(negedge clk);

        // 7. Reset in the middle of counting (count -> 0)
        reset = 1;
        repeat (2) @(negedge clk);
        reset = 0;

        // 8. Count UP a few more cycles (0 -> 3)
        repeat (3) @(negedge clk);

        enable = 0;
        repeat (2) @(negedge clk);
        $finish;
    end
endmodule