// Code your testbench here
// or browse Examples
`timescale 1ns/1ps
module tb;
    reg  clk, resetn, car_waiting;
    wire red, yellow, green;
    wire [1:0] state;
    integer errors;

    traffic_light dut (
        .clk(clk), .resetn(resetn), .car_waiting(car_waiting),
        .red(red), .yellow(yellow), .green(green), .state(state)
    );

    // 10 ns clock (rising edges at 5, 15, 25 ...)
    initial clk = 0;
    always #5 clk = ~clk;

    // Print every state change in the log
    always @(state)
        $display("t=%0t state=%0d R=%b Y=%b G=%b car=%b resetn=%b",
                 $time, state, red, yellow, green, car_waiting, resetn);

    // Checker: exactly one light must be on (checked at every falling edge)
    initial errors = 0;
    always @(negedge clk)
        if ($time > 30 && (red + yellow + green) !== 1) begin
            errors = errors + 1;
            $display("ERROR t=%0t: lights not one-hot R=%b Y=%b G=%b",
                     $time, red, yellow, green);
        end

    initial begin
        $dumpfile("dump.vcd");
        $dumpvars(0, tb);

        resetn = 0; car_waiting = 0;     // t=0   reset
        #23 resetn = 1;                  // t=23  release BETWEEN clock edges
        #7  car_waiting = 1;             // t=30  car arrives, stays for 3 full cycles
        #350 car_waiting = 0;            // t=380 no cars
        #150 car_waiting = 1;            // t=530 car arrives again
        #22 resetn = 0;                  // t=552 ASYNC reset in the middle of GREEN
        #31 resetn = 1;                  // t=583 release between clock edges
        #37 car_waiting = 0;             // t=620 car leaves
        #180;                            // t=800

        $display("ERRORS=%0d", errors);
        if (errors == 0) $display("RESULT: PASS");
        else             $display("RESULT: FAIL");
        $finish;
    end
endmodule