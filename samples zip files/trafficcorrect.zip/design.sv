// Code your design here
// Traffic light FSM, async active-low reset
module traffic_light (
    input        clk,
    input        resetn,        // asynchronous, active low
    input        car_waiting,
    output       red,
    output       yellow,
    output       green,
    output reg [1:0] state
);
    localparam RED = 2'd0, GREEN = 2'd1, YELLOW = 2'd2;
    localparam RED_T = 4, GREEN_T = 5, YELLOW_T = 2;   // cycles per state

    reg [3:0] timer;

    assign red    = (state == RED);
    assign green  = (state == GREEN);
    assign yellow = (state == YELLOW);

    always @(posedge clk or negedge resetn) begin
        if (!resetn) begin
            state <= RED;
            timer <= 4'd0;
        end else begin
            case (state)
                RED: begin
                    if (timer < RED_T - 1)
                        timer <= timer + 4'd1;          // minimum red time
                    else if (car_waiting) begin         // GREEN only if a car waits
                        state <= GREEN;
                        timer <= 4'd0;
                    end                                 // else stay in RED
                end
                GREEN: begin
                    if (timer == GREEN_T - 1) begin
                        state <= YELLOW;
                        timer <= 4'd0;
                    end else
                        timer <= timer + 4'd1;
                end
                YELLOW: begin
                    if (timer == YELLOW_T - 1) begin
                        state <= RED;
                        timer <= 4'd0;
                    end else
                        timer <= timer + 4'd1;
                end
                default: begin                          // illegal state recovery
                    state <= RED;
                    timer <= 4'd0;
                end
            endcase
        end
    end
endmodule